# What was redacted before publishing

This archive is a snapshot of a local sandbox, so it was scrubbed before it was
committed. Every replacement below was applied to every file in the archive, and
the result was re-scanned for each original string (zero hits remain).

| original | replaced with | where it appeared |
| --- | --- | --- |
| OpenViking API key | not present | only ever lived in `env.sh`, which is not in this archive |
| LLM relay API key | not present | only ever lived in `env.sh`, which is not in this archive |
| the private OpenAI-compatible relay hostname | `llm-relay.example.com` | `agent/models.json`, `run.sh`, both `INDEX.md` |
| the operator's local username | `demo-user` | `ls -la` tool output that the agent captured, so it reached the payloads, the session file and the OpenViking archive |

Also removed rather than redacted:

- `env.sh` — the only file that held secrets. `env.sh.example` shows its shape.
- `ext/` — a generated copy of the extension sources, identical to the parent
  directory of this archive.
- `sessions/` and `out/` at the sandbox root — scratch from interactive runs,
  superseded by `demo/` and `demo-long/`.

Deliberately kept, because none of it is a credential:

- pi session ids, OpenViking session ids, archive ids, task ids and trace ids
- `viking://user/default/sessions/...` URIs
- `127.0.0.1` addresses (defaults quoted inside the archived source code)
- the full conversation content, including the extension's own source code,
  which the agent read as part of the task

Verified with: the two key values, the relay hostname and the username each
return zero matches across the archive.
