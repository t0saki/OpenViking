# Demo material — agent-driven context window (pi × OpenViking)

Captured from a passing run of `examples/pi-experimental-context-management/scripts/e2e-window.sh`
on 2026-09-11, model `doubao-seed-2-1-pro-260628` via an OpenAI-compatible relay with
`reasoning_effort: high`. Gate result: 32 checks passed, 2 expected warnings.

OpenViking session (still live on the server, delete it when you are done):

    pi-01a08ec5-bd59-7510-9d04-4e2b89cc7156
    viking://user/default/sessions/pi-01a08ec5-bd59-7510-9d04-4e2b89cc7156/history/archive_001

## What happened

| time | event |
| --- | --- |
| 12:42:20 | pi starts, window w1, nothing archived yet |
| 12:42:38 | model calls `new_context`; extension syncs, posts the handoff note and commits |
| 12:42:48 | Working Memory ready after 15.4 s; window w2 opens, old messages leave the context |
| 12:42:54 | new pi process (`pi -c`) restores w2 from the session file and reproduces the same header |

## Files

| file | what to show |
| --- | --- |
| `cut-summary.txt` | the request before the reset (10 messages, 18 KB) vs after (2 messages, 12 KB) and after a process restart |
| `window-header.txt` | exactly what the model sees in the new window: reason, its own handoff notes, the pending request, the server-generated Working Memory, and how to read the archive back |
| `context-tool-calls.json` | the `new_context` call the model made, with its own `reason` and `notes` |
| `ov-pi.log` | extension timeline: commit, archive wait, window open, restore |
| `session/*.jsonl` | pi session file: `ov-context-window` state entries and the per-prompt `ov-context-status` lines |
| `payloads/payload-t2-01.json` | last provider request of the old window (contains the PADDING-T1 filler) |
| `payloads/payload-t2-02.json` | first provider request of the new window (filler gone, header first) |
| `payloads/payload-t3-01.json` | after `pi -c`: the frozen header again, still no filler |
| `archive/archive_001.overview.md` | the 7-section Working Memory OpenViking generated |
| `archive/archive_001.messages.jsonl` | the archived conversation, including `[tool-result …]` entries |
| `archive/grep-zephyr.json` | `POST /api/v1/search/grep` over the archive: what the `history` tool searches |
| `e2e-gate.log` | the full gate output |

## Suggested demo order

1. `cut-summary.txt` — the context really shrank mid-turn, and stayed shrunk across a restart.
2. `context-tool-calls.json` — the model decided, and said why.
3. `window-header.txt` — what replaced the history.
4. `archive/archive_001.overview.md` — the summary is written by the server, not by the coding model.
5. `archive/grep-zephyr.json` — nothing was lost: the raw conversation is still searchable.
6. `ov-pi.log` — the 15 s cost of one reset.

## Reproduce

    source .tmp/pi-ctxwin/env.sh
    OPENVIKING_URL="$OPENVIKING_URL" OPENVIKING_API_KEY="$OPENVIKING_API_KEY" \
    E2E_LLM_API_KEY="$PI_CTXWIN_LLM_KEY" E2E_LLM_BASE_URL="$PI_CTXWIN_LLM_BASE" \
    E2E_LLM_MODEL="$PI_CTXWIN_LLM_MODEL" E2E_LLM_API=openai-completions \
    E2E_LLM_REASONING=high E2E_KEEP_TMP=1 E2E_KEEP_OV_SESSION=1 \
    bash examples/pi-experimental-context-management/scripts/e2e-window.sh

Add `E2E_WINDOW_FAILCLOSED=both` to also show the refusal path (OpenViking
unreachable: the tool refuses and the context is left untouched).
