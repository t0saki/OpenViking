"""Toy lexer used by the context-window demo."""


class LexerError(Exception):
    """Error raised during lexing."""


def _read_escape(source: str, pos: int) -> tuple[str, int]:
    """Read one escape sequence starting at source[pos] == '\\'."""
    if pos + 1 >= len(source):
        raise LexerError(f"Unterminated escape sequence at position {pos}")
    kind = source[pos + 1]
    if kind == "u":
        # Check that we have at least 4 characters left after '\u'
        if pos + 6 > len(source):
            raise LexerError(f"Incomplete Unicode escape sequence at position {pos}")
        raw = source[pos + 2 : pos + 6]
        # Check that all are hex digits
        if not all(c in '0123456789abcdefABCDEF' for c in raw):
            raise LexerError(f"Invalid hex digits in Unicode escape sequence at position {pos}")
        return chr(int(raw, 16)), pos + 6
    if kind not in {"n", "t", "\\", '"'}:
        raise LexerError(f"Unknown escape sequence '\\{kind}' at position {pos}")
    return {"n": "\n", "t": "\t", "\\": "\\", '"': '"'}[kind], pos + 2


def tokenize(source: str) -> list[str]:
    tokens, buf, pos = [], [], 0
    while pos < len(source):
        ch = source[pos]
        if ch == "\\":
            piece, pos = _read_escape(source, pos)
            buf.append(piece)
        elif ch.isspace():
            if buf:
                tokens.append("".join(buf))
                buf = []
            pos += 1
        else:
            buf.append(ch)
            pos += 1
    if buf:
        tokens.append("".join(buf))
    return tokens
