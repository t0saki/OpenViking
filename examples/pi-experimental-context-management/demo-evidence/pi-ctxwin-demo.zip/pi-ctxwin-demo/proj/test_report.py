#!/usr/bin/env python3
from src.report import Row, render, render_csv


def test_report():
    rows = [
        Row("test1", 12.345, 45.678),
        Row("test2", 98.765, 123.456)
    ]
    
    print("Markdown table:")
    print(render(rows))
    print("\nCSV:")
    print(repr(render_csv(rows)))
    
    # Check the CSV output
    expected_csv = "case,p50,p99\n" \
                   "test1,12.3,45.7\n" \
                   "test2,98.8,123.5\n"
    assert render_csv(rows) == expected_csv, f"CSV mismatch: {repr(render_csv(rows))} vs {repr(expected_csv)}"
    print("✓ All tests passed!")


if __name__ == "__main__":
    test_report()
