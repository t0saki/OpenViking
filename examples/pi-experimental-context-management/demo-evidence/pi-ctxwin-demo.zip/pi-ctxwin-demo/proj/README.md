# ctxwin demo project

A throwaway project for exercising the agent-driven context window:

- `src/tokenize.py` — a lexer with a deliberate bug in `_read_escape`: a `\u`
  escape is sliced without checking that four hex digits follow, so a truncated
  or non-hex sequence raises the wrong error.
- `src/report.py` — unrelated code, used to force a topic switch.
