# Release checklist

- codename: ZEPHYR-9942
- deploy window: Friday 03:00 UTC
- owner: dana-okonkwo
- status: phase one in progress
