# Source Inventory: openviking-pi-extension

All files under `src/`, listed alphabetically.

---

## 1. `src/capture-adapter.mjs`

**Responsibility:** Extracts conversation entries from a pi conversation branch (history) and normalizes them into payloads suitable for archiving to OpenViking. Handles role normalization (user/assistant/tool_result → user/assistant), filters out plugin chatter and slash commands, truncates over-long text, and optionally captures tool results and assistant turns.

**Main exports:**
- `extractBranchCapturePayloads(branch, syncedEntryCount, cfg)` — walks the branch from a watermark, returns `{ payloads, nextEntryCount, observedEntryCount, resetWatermark }`.
- Internal helpers: `normalizeRole`, `rawRole`, `entryPayload`, `faithfulDecision`, `toolResultName`, `toolResultText`.

**Risks / things to watch:**
- Imports from `../shared/capture-utils.mjs` (sibling `shared/` directory outside `src/`).
- Tool results are re-classified as `role: "user"` — downstream archive readers must not assume roles are purely user/assistant.
- Watermark logic (`syncedEntryCount`) resets to 0 if `entries.length < previousCount`; a buggy caller that passes a stale count could re-capture everything.
- Truncation limits (`captureMaxLength` default 24000, `captureToolMaxChars` default 1000000) silently drop content.
- `faithfulDecision` filters out messages starting with `/command` or `[openviking-memory]` — legitimate user messages that happen to start with these patterns will be lost.

---

## 2. `src/capture-adapter.test.mjs`

**Responsibility:** Unit tests for `extractBranchCapturePayloads`. Verifies role normalization, watermark reset, slash-command/plugin-status filtering, tool-result capture (with prefix and truncation), structured tool-part emission, faithful capture of short/ack turns, and de-duplication of tool output in tool-only payloads.

**Main exports:** None (test file, uses node:test runner).

**Risks / things to watch:**
- Imports from `../lib/capture-adapter.mjs` — tests run against compiled output in `lib/`, not source. If build step is stale, tests pass against old code.
- Truncation assertion (`text.length < 500`) is loose; small changes to truncation constants could pass incorrectly.
- No tests for `peerId` being absent, multi-part mixed content, or edge cases like empty branch.

---

## 3. `src/client-archives.test.mjs`

**Responsibility:** Integration-level tests for the archive-related methods on `OVClient` (imported from `../client.ts`). Uses a stubbed `fetch` to mock the OpenViking HTTP API. Covers: session URI resolution/caching (with legacy `viking://session/<sid>` fallback and `~` alias rejection), archive overview reading (YAML frontmatter stripping, OKF sidecar handling, null on not-ready/error), archive message parsing (JSONL line-by-line with malformed/blank placeholders preserving line numbers, tool/context/image/tool-ref part shapes), listing archives (filtering to `archive_NNN` dirs, newest-first ordering, distinguishing empty vs unreadable), grep over archives (regex posting, scoping to one archive, literal escaping, node_limit clamping, path-traversal protection), task status polling, and regression checks on unchanged methods (`commitSessionResponse`, `ls`, `readContent`, `health`, `fetchJSON` timeouts).

**Main exports:** None (test file).

**Risks / things to watch:**
- Imports `OVClient, archiveIdFromUri, archiveUriToRoot` directly from `../client.ts` (TypeScript source), unlike capture-adapter tests which import from `lib/`. Mixed import strategy across tests.
- Stubs `globalThis.fetch` globally in `beforeEach`/`after` — if a test forgets to reset or an assertion throws mid-test, subsequent tests can see a poisoned fetch. The `after` hook does restore `originalFetch`.
- Tests assert on exact URL query parameter encoding (`encodeURIComponent`) — server URL format changes will break many tests at once.
- Line-number preservation in JSONL parsing is critical for `search_contents` grep hit alignment; the placeholder-for-malformed-line design is intentional and tested.
- Archive ID path traversal (`archiveId: "../../etc"`) is explicitly blocked — this is a security-sensitive check.
- `node_limit` clamped between 1 and 4096 (default 256) to prevent server overload.

---

## 4. `src/client.ts`

**Responsibility:** The core HTTP client for the OpenViking REST API. Wraps all endpoints (health, sessions CRUD, commit, search/find, content read/abstract/overview, fs ls/stat/delete, resources ingest, tasks status, and session-archive helpers) with a uniform `fetchJSON` wrapper that normalizes responses to `{ ok, result, error, status, traceId }` and applies timeouts with `AbortController`. The archive section (sessionRootUri, readArchiveOverview, readArchiveMessages, listSessionArchives, grepSessionArchives, getTask) works around the blocked `/archives/{id}` endpoint by going through generic fs/content/search routes against the session root URI; all methods are failure-tolerant (return `null`/`[]` instead of throwing).

**Main exports:**
- `class OVClient` — the client itself. Key public methods: `health`, `createSession`, `getSession`, `getSessionContext`, `addMessage`/`addMessageParts`/`addMessagePayload`, `commitSession`/`commitSessionResponse`, `deleteSession`, `sessionRootUri`, `readArchiveOverview`, `readArchiveMessages`, `listSessionArchives`, `grepSessionArchives`, `getTask`, `find`, `abstract`, `overview`, `readContent`, `ls`, `stat`, `delete`, `addResource`, `resolveScopeSpace`, `resolveTargetUri`.
- Interfaces: `OVSearchResult`, `OVDirEntry`, `OVStatInfo`, `OVSessionMeta`, `OVSessionContext`, `OVCommitResult`, `OVArchiveMessage`, `OVArchiveEntry`, `OVArchiveGrepMatch`, `OVTaskStatus`, `OVCommitResponse`, `OVResponse<T>`.
- Standalone helpers: `archiveUriToRoot(uri)`, `archiveIdFromUri(uri)` (also exposed as static/instance methods).
- Internal helpers (module-private): `uriBasename`, `isNotFound`, `stripTrailingSlash`, `archiveFileFromUri`, `archiveIndex`, `escapeRegExp`, `stripFrontmatter`, `safeStringify`, `renderValue`, `renderToolPart`, `renderPart`, `renderMessageText`.

**Risks / things to watch:**
- `sessionRootUri` caches canonical URIs permanently in `sessionRoots` Map — no eviction; a session whose URI changes on the server will keep using the stale value for the process lifetime.
- `resolvedSpaces` cache has the same lifetime issue for namespace resolution.
- Timeout defaults: most calls 10s, health 5s, archive reads/grep 15s, commit 30s, addResource 30s. AbortController is properly cleared in `finally`.
- `stripFrontmatter` regex `^---[ \t]*\r?\n[\s\S]*?\r?\n---[ \t]*(?:\r?\n|$)` requires the opening `---` to be at position 0; if BOM or leading whitespace is ever introduced, frontmatter leaks to callers.
- `readArchiveMessages` preserves line slots for blank/malformed lines because `search_contents` maps grep line numbers to array indices (`line - 1`). Changing this would silently misalign all grep results.
- Archive methods deliberately distinguish "empty history" (404 → `[]`) from "request failed" (other errors → `null`). Tests enforce this; model-facing `history` tool depends on it to decide whether to tell the user there are no archives.
- `resolveScopeSpace` falls back to `system/status.user` and then `"default"` if namespace listing is empty; if `system/status` is slow, this adds latency to every scope resolution until cached.
- Authorization headers sent on every request (`Bearer`, `X-OpenViking-Account`, `X-OpenViking-User`, `X-OpenViking-Actor-Peer`); misconfiguration sends wrong identity.
- Tool-part rendering accepts many legacy shapes (`output`, `result`, `input`, `arguments`, `args`, `content`, `text`, `tool_output_ref`); the `[tool unknown]` fallback ensures no part reads back as blank.

---

## 5. `src/config.test.mjs`

**Responsibility:** Tests for `loadConfig` / `loadConfigFromModuleUrl`. Uses a temp-directory fixture (`withConfigFile` helper) to write isolated `config.json` (and optional ovcli.conf) files, with environment variable save/restore across every test. Covers: faithful capture defaults, absence of dropped `takeover`/`recallLedger`/`captureMode`/`commitTokenThreshold`/`resumeContextBudget` keys, Unicode path handling in `loadConfigFromModuleUrl`, value clamping (commitKeepRecentCount, captureMaxLength, captureToolMaxChars, recallLimit, scoreThreshold), peer ID precedence (config file < ovcli < env, with workspace-peer derivation as default), debug log path precedence (env `OPENVIKING_DEBUG_LOG` > deprecated `OV_DEBUG_LOG` > config file), context-window defaults shipping correctly, shipped `config.json` matching in-code defaults, per-key clamping for all 11 `contextWindow.*` settings (min/max bounds), boolean normalization of `statusEveryTurn` (strings/0/null), hardPercent auto-lift when below softPercent, env var overrides for `OPENVIKING_CONTEXT_STATUS_EVERY_TURN` and `OPENVIKING_CONTEXT_RESET_DEADLINE_MS`, numeric string coercion, fractional rounding, and a regression test ensuring clamped values don't mutate module defaults.

**Main exports:** None (test file).

**Risks / things to watch:**
- Imports `loadConfig, loadConfigFromModuleUrl` directly from `../config.ts` (TS source, same as client test).
- `withConfigFile` saves/restores 16 env vars manually; missing a var here would leak state between tests. Also uses `mkdtemp` prefix `"ov-pi-config-用户-"` containing Unicode (a Chinese character) — intentional, per the Unicode-path test.
- Context window bounds are driven by a table (`CONTEXT_WINDOW_BOUNDS`) that auto-generates 22 test cases — must stay in sync with `config.ts` clamps.
- Tests import from `../shared/workspace-peer.mjs` (outside `src/`) to compute expected peer ID.
- Documents a known quirk: `Number("")`, `Number([])`, `Number(true)` coerce to 0/1, so they clamp to the min bound instead of falling back to default. Tests pin this behavior.

---

## 6. `src/config.ts`

**Responsibility:** Configuration loading for the extension. Reads `config.json` from the extension directory, layers credentials from env/cli via `resolveOpenVikingCredentials`, applies env var overrides, and clamps every numeric value to safe bounds. The resulting `OVConfig` object drives every other module.

**Main exports:**
- `EXTENSION_VERSION = "0.1.0"` (hand-maintained constant).
- Interfaces: `OVContextWindowConfig`, `OVConfig`.
- `loadConfig(extensionDir)` — main loader, returns a fully-populated clamped `OVConfig`.
- `loadConfigFromModuleUrl(moduleUrl)` — convenience wrapper that resolves the directory from an `import.meta.url`.
- Internal helpers: `envBool`, `clampInt`, `clampNumber`.

**Risks / things to watch:**
- `faithfulCapture` is hard-coded to `true` and cannot be turned off — intentional design decision (archive is the only way back to a closed window).
- Imports from `./shared/credentials.mjs` and `./shared/workspace-peer.mjs` (sibling `shared/` outside `src/`).
- Credential precedence is spread across three layers: file → `resolveOpenVikingCredentials()` → env-var re-checks. The env-var block overwrites endpoint/apiKey/account/user/peerId even when `creds` already resolved them from CLI, so env always wins.
- `recallLimitConfigured` / `recallQueryExpansionConfigured` flags use `hasOwnProperty` to detect whether the user explicitly set these; this matters because downstream code treats presence as "user override" vs default.
- Legacy key aliases are accepted: `recallBudget`, `recallScoreThreshold`, `recallMinQueryLength`, `profileBudget`, `OPENVIKING_BEARER_TOKEN`, `OPENVIKING_BASE_URL`, `OV_DEBUG_LOG`.
- `peerId` final resolution calls `resolveEffectivePeerId` which may derive a workspace-derived peer id; this has side effects (filesystem probe of cwd) at config load time.
- `captureToolResults` normalizes with `!== false`, so any truthy value (including `undefined`) enables it; only explicit `false` disables.
- `hardPercent` is lifted to `softPercent` when configured lower — the hard reminder must never fire before the soft one.
- The spread order `{ ...DEFAULT_CONFIG, ...file, endpoint: creds.baseUrl, … }` means file values override defaults, but then explicit property assignments override both; unknown keys in file/config.json are preserved in the spread (which is how stale keys like `captureMode` still appear on `cfg` even though nothing reads them).

---

## 7. `src/context-window-adapter.test.mjs`

**Responsibility:** Tests for the context window adapter layer — the `io` shim that `context-window-core.mjs` uses to talk to pi, the OV client, the sync module, and the pending-queue. Covers: handoff posting goes directly to `addMessage` (never through queue) with fail-closed on errors, commit keeps `keepRecentCount: 0` with `queueOnFailure: false` and throws become `null`, delegation of `syncBranch`/watermark/sessionId/connectivity, overview/task failure-swallowing, persistEntry and log routing, pending-queue counting scoped to the current session, flush budget pass-through, abortable sleep, core construction defaults, and `readPiReserveTokens` (project settings take priority over global, with `DEFAULT_RESERVE_TOKENS = 16384` fallback, broken JSON tolerated).

**Main exports:** None (test file).

**Risks / things to watch:**
- Imports `createContextWindowManager, readPiReserveTokens` from `../context-window.ts` (TS source), but imports `DEFAULT_RESERVE_TOKENS, pickReserveTokens, readReserveTokens, settingsPaths` from `../lib/pi-settings.mjs` (compiled) and `enqueue` from `../shared/pending-queue.mjs`. Mixed import strategy across modules.
- Uses a `fakes()` factory that constructs a full in-memory double of client/sync/pi/config/logger; overrides are deep-merged via spread, so nested overrides replace whole methods rather than wrapping them.
- Sets `process.env.OPENVIKING_PENDING_DIR` and `PI_CODING_AGENT_DIR` with proper restore in `t.after()` for filesystem-isolated tests.
- Tests an important invariant: handoff notes must NOT go through the pending queue, because queued messages land in the *next* archive, not the one being closed.
- `sleep(60_000, signal)` test verifies abort is prompt (<5s); already-aborted signal resolves immediately.

---

## 8. `src/context-window-core.mjs`

**Responsibility:** The 2031-line pure, harness-agnostic state machine for agent-managed context windows. `ContextWindowCore` tracks token budgets, decides when to fire soft reminders / hard reminders / automatic resets, executes the virtual cut pipeline (archive commit → post handoff → request window close → reopen with working memory), builds status lines and reminder text, and manages persistence of window metadata. It never imports pi-specific APIs — all I/O goes through an injected `io` shim.

**Main exports:**
- Constants: `WINDOW_ENTRY_TYPE`, `WINDOW_HEADER_OPEN`, `WINDOW_HEADER_CLOSE`, `STATUS_CUSTOM_TYPE`, `REMINDER_CUSTOM_TYPE`, `HANDOFF_MARKER`, `STATUS_MARKER`, `REMINDER_MARKER`, `COMPACTION_SENTINEL`.
- Pure helpers: `windowConfig(cfg)`, `computeCutRange(thresholds, tokens, recentCount, reserveTokens)`, `applyWindowCut(messages, cutRange)`, `buildHandoffMessage(notes)`, `buildWindowHeader(id, opened, archiveUri, note)`, `formatTokens(n)`, `formatDuration(ms)`, `effectiveThresholds(cfg)`, `buildStatusLine(status)`, `reminderText(percent, hard, deadlineMs)`, `lastUserTimestamps(branch)`, `lastUserTextFromBranch(branch)`, `messagesFromBranch(branch)`, `siblingToolNamesFromBranch(branch)`, `messageTokens(msg)`.
- `class ContextWindowCore` — the state machine. Key methods: `onTurnEnd()`, `onBeforeTurn()`, `shouldResetNow()`, `checkBudget()`, `getStatus()`, `requestReset(reason, notes)`, `performReset(reason, notes)`, `persist()`, `load()`, `onPostSave()`, `onMessageAdded(msg)`.

**Risks / things to watch:**
- At 2031 lines this is the largest and most complex module; a bug here silently corrupts the agent's own memory.
- Reset is fail-closed: if archive commit or handoff posting fails, the cut is aborted and no history is lost. This means a broken archive endpoint will prevent the window from ever resetting, which could cause unbounded context growth until the model hits the provider limit.
- `computeCutRange` implements a virtual cut — the window keeps `reserveTokens + keepRecentCount` messages at the tail and drops everything before a calculated start index. Off-by-one here would either discard too much (losing critical context) or too little (reset doesn't free enough).
- Pi's native compaction is used as a fallback when OpenViking archiving fails (`COMPACTION_SENTINEL`); if both paths fail the window keeps growing.
- Persistence writes a JSON sidecar; if that file corrupts the core reloads as fresh, which could cause re-capture of already-archived messages.
- Status lines and reminder text are injected as synthetic messages into the conversation with custom types — downstream consumers must recognize `WINDOW_ENTRY_TYPE`, `STATUS_CUSTOM_TYPE`, `REMINDER_CUSTOM_TYPE` or they will surface as garbled assistant text.
- Imports `./text-budget.mjs` for token counting.

---

## 9. `src/context-window-core.test.mjs`

**Responsibility:** Comprehensive test suite (2167 lines) for `ContextWindowCore` and all its exported pure helpers. Tests are organized into sections: config clamping (windowConfig defaults/bounds/idempotency), cut semantics (computeCutRange for single/parallel/missing/gone-anchor cases, applyWindowCut for header merging into string/block/nothing, orphan tool result prevention, compaction summary stripping, idempotent and byte-identical transformContext, boundary release semantics, observeMetrics vs transformContext distinction, messagesFromBranch including compaction replay), header/handoff/status text (buildHandoffMessage, buildWindowHeader with ready/pending/stale/unavailable/undelivered/sibling-truncation variants and Chinese-text truncation budgets, formatTokens/formatDuration, buildStatusLine one-line + idle note, reminderText soft/hard variants, lastUserTimestamps skipping extension-injected messages), requestReset pipeline (full happy-path ordering sync→flush→postHandoff→commit→readArchiveOverview, sibling tool name recording, refusal for disconnected/no-session/not-fully-delivered/flush-fail/handoff-fail/commit-fail/null-commit/no-messages, degraded pending window with polling deadline, early stop on failed task, abort before/after commit, concurrent reset dedup, throw safety, restore byte-identity), refreshPendingOverview (single upgrade, exhaustion to unavailable), reminders (one-fire per level, re-arm on reset, first-observation suppression, local estimate preference, threshold clamping under pi's reserveTokens), status snapshot (usage/idle/advice, fallback while awaiting observation, token counting including tool args and thinking blocks, threshold recomputation for small windows), pi compaction fallback (handleBeforeCompact anchor skip/sentinel/guard/failures, absorbExternalCompaction disarm, stale-header rejection after external compaction, no-stale-notes in automatic compaction), restore/shutdown (newest-wins foreign/malformed entry filtering, fresh session w1, persist dedup, shutdown watermark refresh), adversarial cases (abort-aware sleep rejection, post-commit clock failure, steering user message merge, stale reminder dropping, image-only user messages, Chinese notes merge, per-stage abort, flush budget floor, deadline exhaustion, commit transport error + offline retry, lazy session validation for restored windows, previousOverview round-trip with persist, unavailable overview persistence, terminal task statuses without burning deadline, handoff retraction on refusal, archive ledger with external-compaction gap, rejected-message count naming, pi custom-message reminder shape).

**Main exports:** None (test file).

**Risks / things to watch:**
- Imports from `../lib/context-window-core.mjs` and `../lib/text-budget.mjs` — compiled output, not source. Stale build = green tests against old code.
- Uses `makeIo()` factory with a fake clock (`io.clock` advanced manually via `io.sleep`) for deterministic time-dependent tests; clock state is shared across test calls within one scenario, so ordering matters.
- Fake `io.commit` / `io.postHandoff` / `io.flush` default to returning success — any test that forgets to override a failure mode silently passes the happy path.
- Tests assert on byte-exact header text (including XML-like tags and placeholder JSON strings); even formatting changes in `buildWindowHeader` will break many tests.
- Truncation budget tests use Chinese characters (multi-byte, multi-token) to exercise token-based (not character-based) truncation — depends on `estimateTokens` accuracy.
- Tests for commit transport errors explicitly verify fail-closed semantics (nothing cut, retraction handoff posted, `lastCommitError` stored, offline short-circuit) — this is the safety-critical path.
- The `recentResetGuardMs` (60s) prevents double-commits when pi's native compaction fires right after a successful `new_context`; tests verify no second commit inside the window but one after it.
- Archive ledger tests verify that windows closed by external (pi) compaction without an archive are not recorded — critical for accurate `archiveCount`.
- Lazy session validation (`pendingSessionCheck`) handles the case where a window entry is restored before the ov session id is known; tested via `restoredIn()` helper that starts with `sid: null`.

---

## 10. `src/context-window.ts`

**Responsibility:** The adapter that binds the pure `ContextWindowCore` (imported from compiled `./lib/context-window-core.mjs`) to pi, the `OVClient`, and the `SyncManager`. Constructs the `io` shim — every effectful operation the state machine needs (sync, flush, handoff posting, commit, archive overview reading, task polling, persistence, watermark/time/sleep/log/connectivity/session id) — and passes it into a new `ContextWindowCore` instance. Also exports `readPiReserveTokens` which reads pi's `reserveTokens` setting from project and global settings files.

**Main exports:**
- `createContextWindowManager({ pi, client, sync, config, logger? })` — returns a `ContextWindowCore` instance wired to real pi/OV/sync.
- `readPiReserveTokens(cwd?)` — reads `compaction.reserveTokens` from `.pi/settings.json` (project) then `~/.pi/agent/settings.json` (global), with fallback to `DEFAULT_RESERVE_TOKENS = 16384`.
- Internal helpers: `countUndeliveredForSession(pendingEntries, sid)`, `abortableSleep(ms, signal?)`.

**Risks / things to watch:**
- Imports `ContextWindowCore` from `./lib/context-window-core.mjs` (compiled output), not from `./context-window-core.mjs` source. Same for `DEFAULT_RESERVE_TOKENS, readReserveTokens` from `./lib/pi-settings.mjs`. Stale builds will wire the wrong core.
- `postHandoff` calls `client.addMessage` directly (never queued) — this is an intentional safety invariant: a queued handoff would land in the *next* archive rather than in the window being closed. Any refactor that routes this through the pending queue would corrupt history.
- `commit` passes `queueOnFailure: false` for the same reason: a late commit would split a window the model still believes is inside.
- Every `io` method that calls the client has a `try/catch` returning `null`/`false` on throw — fail-closed, consistent with the core's design.
- `pendingCache` is refreshed synchronously only after a failed flush (the one moment the core needs an accurate count, for the refusal message). Between flushes the cached number may be stale.
- `readPiReserveTokens` uses `createRequire(import.meta.url)` to optionally resolve `@earendil-works/pi-coding-agent` and read `CONFIG_DIR_NAME`; if that package is not resolvable (tests, standalone checkout) it falls back to the literal `".pi"`. Any error in `readReserveTokens` also yields the default 16384 — silently.
- Imports `listPending` from `./shared/pending-queue.mjs` (outside `src/`).
- The `pi` parameter is typed `any`; structural typing relies on `pi.appendEntry(customType, data)` existing.

---

## 11. `src/index-load.test.mjs`

**Responsibility:** End-to-end smoke and integration tests that load `src/index.ts` through pi's own jiti loader (the same way pi loads extensions at runtime), point it at either a dead port or a fake in-process HTTP server, and drive the full lifecycle: event handler registration, tool/command surfacing, system-prompt injection, first status line, `new_context` reset through commit → archive → virtual cut → reminder firing, `history` tool (list_windows/list_items/read_item/search_contents), `get_context_remaining`, offline restore with persisted window entry, peer extension coexistence (stand-down when another OV extension registered `viking_search`), provider-error/abort turn-end not re-arming reminders, recall failure not killing the cut, blocked/empty archive listing error messages, offline `session_before_compact` recent-reset guard, and window id survival across a compaction that produced no archive. Also asserts removed modules (`takeover.ts`, `lib/takeover-core.mjs`, `shared/recall-ledger.mjs`) do not exist.

**Main exports:** None (test file).

**Risks / things to watch:**
- **Requires jiti** — tests are marked `{ skip: !JITI_PATH }` and skip entirely if pi's jiti cannot be found (homebrew path, local node_modules, or `PI_JITI_PATH` env). In CI without jiti, the whole suite is a no-op.
- Loads `index.ts` through jiti with `interopDefault: true` — a plain `import()` would not resolve TypeScript or `.js`-suffixed specifiers; tests must continue using jiti to reflect real pi loading.
- Spawns a real HTTP server (`createServer`) for fake OV routes: `/health`, `/messages/batch`, `/messages`, `/commit`, session lookup, `/api/v1/fs/ls` (with `blockLs`/`emptyLs` variants), `/api/v1/content/read` (serves `.overview.md` and `messages.jsonl`), `/api/v1/search/grep`, `/api/v1/search/recall`. Only covers the handful of routes used by one reset + history; new routes need new fake handlers.
- Uses a temp `OPENVIKING_PENDING_DIR` per test to isolate pending-queue state from other tests.
- `withDeadServer(t)` points OV at `http://127.0.0.1:1` (port 1 refuses immediately) to verify offline half arms correctly.
- Fake `ARCHIVED_MESSAGES` uses a 9000-char string to exercise truncation in `list_items` (clip) vs `read_item` (full `historyItemMaxChars = 8000`).
- Tests assert the deprecated `viking_archive_expand` tool is NOT registered — regression guard.
- Tests verify the system prompt does NOT contain "never mention/disclose/reveal" — Codex-style hiding is deliberately absent in this fork.
- Peer detection uses `pi.getAllTools()` and inspects `sourceInfo.path` to tell self from peer; if pi changes how it reports tool source, the stand-down logic misfires.
- Tests verify `executionMode: "sequential"` on `new_context` — this prevents pi from parallelizing a reset with other tool calls.
- Tests assert that after a reset the same turn's `turn_end` must NOT fire a reminder (would cause a second immediate reset), and that each reminder level fires only once per window.
- The recall-failure test deliberately passes malformed messages (`content: null`, `null` entry) to verify the context hook never throws — pi keeps the untransformed list on throw, which would hand archived context back to the model.

---

## 12. src/index.ts

**Responsibility:** Main extension entry point — the default async function that pi loads. Initializes all modules (OVClient, SyncManager, RecallManager, context-window manager, logger), registers all 9 tools via `registerTools`/`registerContextWindowTools`, registers the "viking" CLI command, and wires up 9 event handlers (`session_start`, `before_agent_start`, `context`, `tool_call`, `turn_end`, `session_before_compact`, `session_compact`, `session_shutdown`, `agent_end`). Embeds the static `CONTEXT_WINDOW_GUIDANCE` system-prompt block and the `TOOL_LIST_LINE` summary.

**Main exports:**
- `default` (async function) — the only export; receives the pi `ExtensionAPI`, loads config via `loadConfigFromModuleUrl(import.meta.url)`, builds the module graph, registers everything. Returns early (no-op) when `config.enabled` is false.
- Helper functions (`matchBypass`, `buildSessionProfileBlock`, `updateStatus`, `statusMessages`, `standDownIfPeerActive`, `peerOwnsToolSurface`, `start`) are module-private closures.

**Key internal details:**
- Two-phase startup: `session_start` fires-and-forgets `start()` (so OV health/profile latency doesn't block UI); `before_agent_start` awaits the same memoized `startPromise` so the first provider request waits for the chain to finish.
- `start()` itself splits into offline init (session id derivation via `sync.ensureSession`, window restore `windows.restore`, tool registration — must succeed even when OV is down so `pi -c` doesn't replay archived windows) and online init (health check, pending replay, profile build).
- Coexistence probe (`peerOwnsToolSurface`) inspects `pi.getAllTools()` and compares each tool's `sourceInfo.path` with `ownDir` (derived via `dirname(fileURLToPath(import.meta.url))`); re-run on every event boundary because the peer extension registers tools asynchronously after its own health check. If peer detected before any irreversible work (no window open, no syncs, windowIndex=1), the extension stands down cleanly (`bypassed = true`); if already engaged, it warns via `ui.notify` and keeps going.
- `context` hook: runs `windows.transformContext(event.messages)` first (cut is network-independent and must never be skipped), then wraps recall in try/catch so recall failure falls back to the cut-but-no-recall list rather than the raw untransformed list (which would hand archived windows back to the model).
- `turn_end` handler: syncs branch if connected and `config.syncTurns`; re-arms reminders only for usable assistant responses (skipping `stopReason === "aborted"|"error"` and messages timestamped before `lastResetAt`); fires due reminders as custom `REMINDER_CUSTOM_TYPE` messages delivered via `sendMessage` with `deliverAs: "steer"` (mid-batch) or `"nextTurn"`; calls `windows.refreshPendingOverview()` (one retry per turn for deferred Working Memory); updates status bar.
- `session_before_compact` delegates to `windows.handleBeforeCompact` to replace pi's native summarizer with OV archival; returns undefined on any failure, letting pi fall back to its own compaction.
- `session_compact` calls `windows.absorbExternalCompaction("pi compaction")` when pi compacted without extension involvement (stale virtual anchor).
- `tool_call` handler runs `guardVikingUriToolCall(event)` to validate `viking://` URIs before tool execution.
- `session_shutdown` calls `windows.shutdown()` (persists window state with final watermark, no forced commit) then `sync.shutdown()`.
- `agent_end` calls `recall.invalidate()` to clear cached recall state.
- "viking" command subcommands: `window` (status snapshot including archive id/working-memory readiness/advice), `commit` (sync+commit with trace_id reporting), and bare (connection/session/window one-liner).
- Bypass patterns: simple prefix/glob matching via `matchBypass` (supports leading `*` suffix, trailing `*` prefix, exact, and directory-prefix); matched cwd sets `bypassed = true` and disables the extension entirely.

**Risks:**
- `ownDir` detection and `sourceInfo.path` comparison are fragile against pi API changes; if pi changes how it reports tool source, stand-down logic could mis-identify a peer as self (silent double-write to OV) or self as peer (false stand-down).
- Heavy use of `any` casts for pi internal APIs (`getAllTools`, `getContextUsage`, `sessionManager.getBranch()`, `sendMessage`, `setStatus`, `ui.notify`); pi API drift will produce runtime errors caught only by broad try/catch blocks (best-effort status/reminder updates).
- The `context` hook wraps recall in try/catch but NOT the window cut itself; an unexpected throw in `windows.transformContext` would still fall through to pi's default (keeping untransformed messages and handing archived content back).
- `tool_call` guard fires for ALL tool calls, not just `viking_*` ones; relies on `guardVikingUriToolCall` returning undefined for non-viking tools.
- Reminder delivery depends on `sendMessage` supporting the `deliverAs: "steer"|"nextTurn"` option; shape changes silently drop reminders (caught and logged).
- The two-phase startup shares a single `startPromise`; if `session_start`'s fire-and-forget rejects, the error is only logged and `before_agent_start` awaits the same (already-rejected) promise.
- `updateStatus` catches all errors from `statusSnapshot` and `setStatus` — silent failures hide status bar problems.

---

## 13. src/pi-settings.mjs

**Responsibility:** Reads pi's own `settings.json` (project and global) to extract `compaction.reserveTokens`, without importing pi itself. The context-window manager needs this value because pi auto-compacts once `contextTokens > contextWindow - reserveTokens`; hard reminders must be clamped under that line or the model's handoff notes are never written before pi's native compaction fires.

**Main exports:**
- `DEFAULT_RESERVE_TOKENS` (const = 16384) — pi's built-in default when no reserve value is set.
- `reserveTokensFromSettings(settings)` — extracts and validates `compaction.reserveTokens` from one parsed settings object; returns floor of the number or null if missing/invalid/negative/non-finite.
- `pickReserveTokens(contents)` — given an array of raw file text (or null for missing), returns the first valid reserveTokens found in order (project file wins), else DEFAULT_RESERVE_TOKENS. JSON parse errors are treated as "missing" so a broken file doesn't hide the other.
- `settingsPaths(opts)` — returns the ordered list of settings file paths: `<cwd>/<configDirName>/settings.json` first, then either `<agentDir>/settings.json` (if PI_CODING_AGENT_DIR override supplied) or `<homeDir>/<configDirName>/agent/settings.json`.
- `readReserveTokens(opts)` — high-level reader: builds paths via `settingsPaths`, reads each with an injected or default `readFile` (uses `readFileSync`, returns null on ENOENT/error), and calls `pickReserveTokens`. `readFile` is injectable for testing without touching the real filesystem.

**Risks:**
- Resolution order mirrors pi's `SettingsManager` (project over global over agentDir override); if pi changes that precedence or adds new config locations, the clamping math will be off by up to `reserveTokens` and reminders could fire inside pi's auto-compaction zone, losing handoff notes.
- Very defensive (every step returns null on error, default fallback), but that means a malformed global settings.json is silently ignored — users may be running with DEFAULT_RESERVE_TOKENS without realizing it.
- No file watching; if settings.json changes mid-session the reserve value stays at process-start value.

---

## 14. src/recall-deferred.test.mjs

**Responsibility:** Tests for RecallManager's deferred recall flow — verifies that recall is queued without I/O during `before_agent_start`, awaited in the `context` hook, and injected into the user message. Three test cases cover the deferred-search lifecycle, session-id propagation, and short-prompt cache clearing.

**Main exports:** None (test file). Uses `node:test` and `node:assert/strict`. Imports `RecallManager` from `../recall.ts` (TypeScript source, not compiled lib/).

**Test cases:**
1. Queued recall waits for `searchPending()` — verifies `queueSearch()` does zero I/O, `searchPending()` makes exactly one POST to `/api/v1/search/search` with `mode: "context"`, `injectRecall()` appends the rendered memory block after the original prompt, and subsequent `searchPending()` calls reuse the cached result (no duplicate I/O).
2. Session id is sent when available — verifies the sessionId getter (supplied at construction, nullable) is read at search time (not queue time), so when sync sets the id mid-lifecycle the second search includes `session_id` and `dedup_turns`.
3. Short prompt clears previous recall — verifies that queueing a query shorter than `minQueryLength` (3) clears any previously cached recall block so stale memory isn't injected.

**Risks:**
- Imports directly from `../recall.ts` (source), not compiled `lib/` — depends on the test runner's TS loader being configured identically to production jiti path.
- Stubs `client.fetchJSON` but does not verify HTTP method, headers, or error handling; failure paths (non-ok response, network error, empty rendered) are not covered here.
- `config()` helper hardcodes `recallTokenBudget: 2000`, `scoreThreshold: 0.35`, etc.; if defaults change in config.ts these tests may mask drift.

---

## 15. src/recall.ts

**Responsibility:** RecallManager — queues a semantic search against OpenViking for the current user prompt and injects the rendered recall block into the newest user message before the provider sees it. Designed as a two-phase deferred flow: `queueSearch` (called from `before_agent_start`, no I/O) stores the prompt; `searchPending` (called from the `context` hook) performs the search via `buildRecallBlock` and caches the result; `injectRecall` prepends the block to the newest user message.

**Main exports:**
- `RecallCache` interface — `{ block: string | null; promptText: string }`.
- `RecallManager` class with methods:
  - `constructor(client, config, sessionIdGetter?)` — sessionId is a lazy getter because SyncManager (which owns the id) is constructed after RecallManager.
  - `queueSearch(userQuery)` — stores the prompt without I/O.
  - `searchPending()` — performs the search via `./shared/recall-core.mjs`'s `buildRecallBlock`; returns cached block if no pending prompt; returns null and clears cache if query is shorter than `minQueryLength`; passes `peerId` and lazily-read `sessionId()` to enable server-side query expansion and cross-turn dedup.
  - `injectRecall(messages)` — locates the newest user message (scanning backwards), skips if message already contains `<openviking-context` (idempotency guard against double-injection on re-entrant calls or frozen headers), and prepends the cached block. Handles both string content and multimodal (array-of-blocks) content, prepending to the first text block.
  - `invalidate()` — clears cache and pending prompt (called on `agent_end`).
- Module-private helpers: `textOf(msg)` (extracts text from string or array content), `prependBlock(msg, block)` (mutates msg.content in place).

**Risks:**
- `injectRecall` mutates the `messages` array elements in place (`msg.content = block + "\n" + msg.content` and mutates `textBlocks[0].text`), relying on pi providing a deep copy to the `context` hook. If pi ever passes shared references, the recall block would persist into archived/history views.
- Idempotency guard is a simple substring check for `<openviking-context` — a user message that naturally contains that string (unlikely but possible in technical conversation) would suppress recall for that turn.
- Search timeout defaults to 10s but defers to `options?.timeoutMs` from the shared helper; however the comment notes that ignoring the helper's deadline "would abort a request still inside its fuse" — the actual passthrough only forwards `options?.timeoutMs`, not any other deadline fields.
- No error handling inside `searchPending` itself (the caller in index.ts wraps it in try/catch); any throw from `buildRecallBlock` propagates out.
- Scans backward for the newest user message but doesn't skip non-text roles beyond checking `role === "user"`; tool results or system-inserted messages with role "user" could receive the prepend.

---

## 16. src/sync-barrier.test.mjs

**Responsibility:** Test suite for SyncManager's backlog/flush barrier, batch writes, watermark restore, retry semantics, and commit logging. Focuses on the queued-delivery path (messages that fail to reach OV are persisted to `OPENVIKING_PENDING_DIR` and replayed later) and the barrier that gates `new_context` until all current-session messages are delivered.

**Main exports:** None (test file). Uses `node:test`, `node:assert/strict`, `node:fs/promises`, temp directories via `mkdtemp`. Imports `SyncManager` from `../sync.ts` (TypeScript source) and `enqueue`, `listPending` from `../shared/pending-queue.mjs`.

**Test cases (14 tests):**
1. `syncBranch` returns `{ added, tokens, allDelivered }` accounting.
2. Commit success writes a JSON record to the debug log with `hook: "pi"`, `stage: "commit"`, trace_id.
3. Commit failure (HTTP 500) writes `ok: false` with error message and trace_id.
4. Queued addMessage keeps flush barrier closed until replay succeeds — toggling `replayOk` opens barrier and drains.
5. Current-session addMessage 500 stays queued with correct entry type/sessionId.
6. Other-session queued addMessage and commitSession entries do NOT block the barrier (barrier is per-session).
7. `restoreWatermark(n)` skips first n branch entries so `pi -c` doesn't re-sync already-captured messages.
8. `syncBranch` sends the whole turn in ONE batch POST to `/messages/batch`, not one request per message.
9. Backlog drain batches in chunks of 100 (250 messages → 100/100/50), preserves order, leaves other-session entries queued.
10. Failed batch (HTTP 500) increments retry counter on the first 100 entries, leaves the other 20 untouched, barrier stays closed.
11. Non-retryable failure (HTTP 400 "bad") drops payloads but still advances the sync watermark (prevents infinite poison-payload loops).
12. `OPENVIKING_PENDING_DRAIN_MAX_BATCHES` env var caps drain per turn (set to 1 → first 100 drain, 150 remain).
13. `flushBarrier({ budgetMs: 0 })` caps total drain time so a reset-triggered flush can't hang; zero budget sends nothing and reports closed. Fallback env `OPENVIKING_PENDING_DRAIN_BUDGET_MS` also honored.
14. `syncBranch` never auto-commits — the old `commitTokenThreshold` config key is intentionally gone; `commitIfNeeded` is undefined; even 10M pending tokens triggers zero commits. Archive boundaries belong only to the reset path.

**Risks:**
- Imports from `../sync.ts` source; TS-loading configuration matters.
- Uses temp dirs and mutates `process.env.OPENVIKING_PENDING_DIR`, `_MAX_BATCHES`, `_BUDGET_MS` with proper restore in finally blocks — but if a test fails mid-execution before finally, env vars could leak to subsequent tests (though node:test isolates files, not process).
- Stubs client methods but doesn't test network-level failures (socket hang-up, timeout, malformed JSON responses).
- Heavy use of shared pending-queue module state; tests rely on `withPendingDir` isolation to avoid cross-test pollution.

---

## 17. src/sync.ts

**Responsibility:** SyncManager — owns the OpenViking session id, the sync watermark (`syncedEntryCount`), the queue of undelivered messages, and the flush barrier that gates context-window resets. Extracts capture payloads from the conversation branch via `extractBranchCapturePayloads`, sends them to OV in batch, persists retryable failures to disk (pending queue), replays them on startup and on demand, and performs session commits (archive boundaries). Deliberately does NOT auto-commit on token thresholds — archive boundaries are written only by `new_context` and the pi compaction fallback.

**Main exports:**
- `AddPayloadResult` interface: `{ accepted: boolean; delivered: boolean }`.
- `SyncBranchResult` interface: `{ added: number; tokens: number; allDelivered: boolean }`.
- `SyncManager` class with methods:
  - `constructor(client, config)` — creates logger via `createLogger("pi", ...)` tied to `config.debugLogPath`.
  - Getters: `sessionId`, `syncedCount`, `droppedCount` (messages permanently lost — non-retryable 4xx or retry budget exhausted), `commitTraceId`.
  - `restoreWatermark(n)` — sets syncedEntryCount (used by `windows.restore` on `pi -c` to skip already-captured entries).
  - `ensureSession(piSessionId)` — derives OV session id via `deriveHarnessSessionId("pi-", piSessionId)`; memoized (returns true immediately if already set).
  - `replayPending()` — delegates to shared `replayPending()` with a 10s fetch wrapper and logger; no-op when not connected.
  - `flushBarrier({ budgetMs })` — gates resets: drains session backlog (bounded by `budgetMs` or `OPENVIKING_PENDING_DRAIN_BUDGET_MS` default 60s, plus `OPENVIKING_PENDING_DRAIN_MAX_BATCHES`), then returns true iff zero current-session addMessage entries remain queued.
  - `drainSessionBacklog(budgetMs?)` (private) — claims pending addMessage entries in batches of `BATCH_LIMIT` (100), sends via `sendSessionMessages`, dequeues on success, increments retry (or drops permanently) on failure. Stops early on time/max-batches budget.
  - `syncBranch(branch)` — extracts payloads from the branch starting at `syncedEntryCount`, sends them, accumulates token estimates via `estimatePayloadTokens`, advances watermark on full success, returns `{ added, tokens, allDelivered }`.
  - `addPayload(payload)` — sends a single payload, returns `{ accepted, delivered }`.
  - `sendPayloads(payloads)` (private) — sends via `sendSessionMessages(this.fetchJSON, sid, payloads, { enqueueOnRetryable: true })`; retries go to disk, non-retryable failures (4xx) are counted as dropped-forever but still advance the watermark (prevent poison-payload infinite loops).
  - `commit({ queueOnFailure, keepRecentCount })` — calls `client.commitSessionResponse`, logs success/failure with trace_id, enqueues a commitSession entry on failure unless `queueOnFailure: false`, returns the result or null.
  - `shutdown()` — currently a no-op (explicit comment: no forced commit on exit, to avoid splitting windows across processes).
- Module-private helper: `countUndeliveredForSession(pendingEntries, sid)` filters pending entries to count addMessage entries matching the session.

**Key design choices:**
- The flush barrier is fail-closed for resets: if any current-session messages remain queued (including those marked `.processing` from a claimed batch), the barrier returns false and the reset is refused.
- Non-retryable failures (4xx) are dropped permanently and counted in `droppedForever`; this counter is exposed separately from `syncedCount` so callers can detect archive gaps.
- Batch send uses `BATCH_LIMIT` (100) per request; backlog drain stops early when time budget or max-batch limit is reached, leaving the remainder for later turns.

**Risks:**
- `ensureSession` is purely local (derives id via `deriveHarnessSessionId`, no server round-trip); if the server has a different session id scheme, messages will be misrouted.
- `shutdown()` is a no-op — no final flush on exit. The comment says this is intentional (commit boundaries belong to reset path), but an abrupt exit during a large backlog leaves everything queued for next process.
- `drainSessionBacklog` iterates `backlog.slice(start, start+BATCH_LIMIT)` but `start += BATCH_LIMIT` at each loop iteration; within a batch, entries are claimed individually — if `claimForReplay` returns null (already claimed by another process), the batch is shortened silently. After a failed batch the method returns (not continues), leaving later batches for the next call — this is intentional but means one failed batch pauses the entire drain.
- `sendPayloads` counts non-retryable failures as `accepted: res.sent + res.queued + dropped` — the watermark advances past poison messages, which is correct for preventing loops but means those messages are permanently absent from the archive (tracked via `droppedForever`).
- `fetchJSON` is an arrow-field (10s timeout), not a method — subclasses or spies that replace `this.client.fetchJSON` after construction won't be seen if `this.fetchJSON` is captured elsewhere.

---

## 18. src/text-budget.mjs

**Responsibility:** Pure text/token utility helpers shared between the context-window core (`context-window-core.mjs`) and the sync manager (`sync.ts`). Extracted from the takeover core of the upstream pi extension so this fork can reuse token estimation, content flattening, user-turn detection, and truncation without carrying the takeover state machine.

**Main exports:**
- `CONTEXT_BLOCK_MARKER` = `"<openviking-context"` — prefix that marks every synthetic user message this extension injects (recall block, window header); used to distinguish synthetic turns from human turns.
- `flattenContent(msg)` — recursively extracts the concatenated text from a message's `content` field, handling strings, arrays of parts, and objects with `text`/`input_text`/`output_text`/`content` fields.
- `fingerprintMessage(msg)` — returns a stable fingerprint string `"role:length:first200chars"` for deduplication.
- `isUserTurnStart(msg)` — true iff `msg.role === "user"` AND its flattened text does NOT start with `CONTEXT_BLOCK_MARKER` (i.e. a real human message, not an injected block).
- `countUserTurns(messages)` — counts human user turns (messages where `isUserTurnStart` is true).
- `estimateTokens(text)` — rough token estimator: CJK characters (codepoint >= 0x3000) count as 1.5 tokens, everything else as 0.25 tokens (1/4), rounded up. Not a real tokenizer but fast and stable.
- `truncateToTokens(text, budget)` — binary-searches the longest prefix of `text` whose `estimateTokens` is <= budget, via repeated slicing.
- `estimatePayloadTokens(payload)` — estimates tokens for an OV capture payload: handles `content` string, `parts[]` array (tool parts serialized as JSON with name/input/output/status), and `content[]` multimodal arrays.

**Risks:**
- `estimateTokens` is a heuristic, not a real tokenizer — actual token counts from the model's tokenizer will differ; thresholds derived from it (status line percentages, cut ranges, truncation budgets) are approximate.
- CJK detection uses `codePointAt(0) >= 0x3000` which is a coarse heuristic covering CJK Unified Ideographs, Hangul, Hiragana, Katakana, but also non-CJK symbols in that range and misses some CJK extensions below 0x3000.
- Binary search in `truncateToTokens` calls `estimateTokens(value.slice(0, mid))` at each step — O(log n) estimates, each O(mid) string scan, acceptable for budget sizes but O(n log n) total.
- `partText` for tool parts uses JSON.stringify on `{name, input, output, status}`; if tool_input/output contain circular references, the try/catch falls back to a coarse string. If those objects are very large this string dominates the token budget.
- `flattenValue` does not recurse into arbitrary keys — only `text`, `input_text`, `output_text`, `content`; content blocks with custom text fields will be silently skipped.

---

## 19. src/text-budget.test.mjs

**Responsibility:** Unit tests for the pure helpers in text-budget.mjs. Covers content flattening, message fingerprinting, user-turn detection (including the CONTEXT_BLOCK_MARKER skip), token estimation (ASCII and CJK), binary-search truncation, and payload token counting for structured parts.

**Main exports:** None (test file). Uses `node:test`, `node:assert/strict`. Imports from `../lib/text-budget.mjs` (compiled output, NOT source — contrasts with recall-deferred.test.mjs which imports from .ts source).

**Test cases (7 tests):**
1. `flattenContent` handles plain strings, arrays of text/image parts (concatenating text parts and ignoring image parts), and null/null-content inputs.
2. `fingerprintMessage` produces `role:length:first200chars`; same text under different roles yields different fingerprints.
3. `isUserTurnStart` returns false for assistant messages and for user messages starting with CONTEXT_BLOCK_MARKER (synthetic injection); `countUserTurns` correctly counts only human turns (2 in the 4-message fixture).
4. `estimateTokens`: empty string → 0; 100 ASCII → 25 (÷4); 10 CJK → 15 (×1.5); mixed "界界" + 8 ASCII → 5 (ceil(3+2)); `truncateToTokens` respects budget, returns "" for budget 0, returns full text when within budget; long CJK truncation stays under 3000 tokens and under 2500 chars.
5. `truncateToTokens` returns the longest prefix exactly on budget — 400 ASCII at budget 10 cuts to 40 chars (10 tokens), and the next char would exceed budget.
6. `estimatePayloadTokens` for `{content: 40 a's}` → 10 tokens; null → 0; structured parts (text block + running tool block) produce a count larger than 10 (tool JSON adds overhead).

**Risks:**
- Imports from `../lib/text-budget.mjs` (compiled output) — if the build is stale these tests pass against old code while source-level consumers use newer logic.
- CJK test uses only U+754C (界); does not test the boundary at codepoint 0x3000 (e.g. U+2FFF vs U+3000) or mixed CJK+ASCII edge cases around the `ceil` rounding.
- No tests for multimodal content arrays (payload.content as array of parts), nested content objects, or tool parts with circular JSON (the JSON.stringify try/catch path).
- No test for binary search convergence on strings where token estimate doesn't monotonically increase by 1 per character (e.g. emoji, surrogate pairs).

---

## 20. src/tools.ts

**Responsibility:** Registers all 9 pi tools — the 6 `viking_*` knowledge-base tools (`registerTools`) and the 3 context-window tools (`registerContextWindowTools`): `new_context`, `history`, `get_context_remaining`. Each tool is defined with a TypeBox schema, prompt snippets/guidelines, and an async execute handler that talks to OVClient, SyncManager, or ContextWindowCore.

**Main exports:**
- `registerTools(pi, client, sync?)` — registers the 6 viking_* tools:
  1. `viking_search` — semantic search via `client.find`; truncates abstracts to `recallMaxContentChars`; returns results with score, URI, and abstract; offline returns "not reachable".
  2. `viking_read` — reads content at a viking:// URI at one of three levels (abstract/overview/full) via `client.abstract`/`client.overview`/`client.readContent`.
  3. `viking_browse` — filesystem-style browsing: `action: "list"` via `client.ls` (with 📁/📄 icons), `action: "stat"` via `client.stat`.
  4. `viking_remember` — stores a tagged `[Remember — <category>] <content>` user message directly to the OV session via `client.addMessage` when a sync session is available; returns stored/failure message.
  5. `viking_forget` — deletes by exact URI via `client.delete`, or by query (finds top match, requires score > 0.8 before deleting).
  6. `viking_add_resource` — ingests a URL via `client.addResource`; HTTP only.
- `ContextWindowToolOptions` interface — `{ getMessages?, reserveTokens? }`.
- `registerContextWindowTools(pi, client, sync, windows, config, opts?)` — registers:
  7. `new_context` (executionMode: "sequential") — calls `windows.requestReset` with reason/notes/next_steps/toolCallId/branch/signal, streaming progress via `onUpdate`; returns result text (which on refusal starts with "Context window NOT reset"). Never calls `terminate` — a refusal leaves the agent running, a successful reset is consumed by the next context hook.
  8. `history` — four actions via switch/case:
     - `list_windows` — lists archives oldest-first via `client.listSessionArchives`, maps them to window ids (using recorded `windows.archives` map with positional `wN` fallback), appends the current open window; offline/error returns specific diagnostic text distinguishing "unreadable server" from "empty history".
     - `list_items` — reads messages via `client.readArchiveMessages`, paginated with offset/limit (default 40, max 200), renders one-line previews.
     - `read_item` — parses item refs like `w2:14` (window-qualified) or `14` (with window param), returns full message text clipped to `config.contextWindow.historyItemMaxChars`.
     - `search_contents` — greps via `client.grepSessionArchives` with case-insensitive regex; invalid regex patterns fall back to literal search; results are grouped by window with read_item pointers derived from `messages.jsonl` line number (line - 1 = item index).
  9. `get_context_remaining` — takes no parameters; calls `windows.statusSnapshot` with usage/messages/reserveTokens and renders the multi-line status report via `renderStatusReport`.

**Module-private helpers:** `text(body, details?)` (standard content response), `clip(raw, max)` (truncation with "… [truncated, N more chars]" trailer), `firstLine(raw)` (for Working Memory abstract), `orderedArchives(archives)` (reverse chronological → oldest first), `windowIdsFor(ordered, recorded)` (maps archiveId→windowId from recorded ledger with wN fallback), `resolveArchive(spec, ordered, windowIds)` (accepts "w2", "2", or "archive_002"), `parseItemRef(item, windowSpec?)` (parses "w2:14" and bare "14"), `renderItemLine(windowId, index, msg)`, `oneLine(raw)`, `renderStatusReport(snap)` (multi-line report including tokens_left, used%, window age, turns, idle gaps, archive count/WM readiness, undelivered count, accuracy, advice).

**Risks:**
- Every viking_* tool checks `client.connected` and returns a "not reachable" text, but does NOT use AbortSignal — long-running searches/reads can't be cancelled by the user.
- `viking_remember` only stores when `sync?.sessionId` exists; if called before session init, it returns a "not stored" message asking the model to repeat in handoff notes — relies on model compliance.
- `viking_forget` with a query deletes the top hit if score > 0.8; false positives could delete unintended memories (irreversible).
- `history` tool's archive-null return text explicitly tells the model not to conclude empty history, but relies on the model reading and obeying that natural-language instruction.
- `history list_items` clips messages to `historyItemMaxChars` but `read_item` also clips — reading an item in full still isn't truly full (large tool outputs can be truncated silently).
- search_contents derives item index from `line - 1` in messages.jsonl, assuming one message per line — any multi-line JSON message would produce a wrong pointer.
- Invalid regex in search_contents falls back to literal search, but case-insensitive literal search with special regex chars (`.`, `*`) still works server-side as literal; no client-side escaping is done.
- Heavy `any` typing throughout for pi registerTool/ctx APIs; tool registration failures (e.g. pi requiring additional schema fields) surface only at runtime.
- `resolveArchive` accepts bare numbers like "2" as window references — ambiguous between "w2" and archive_002 if numbering collides; only explicit "archive_XXX" form disambiguates.

---

## 21. src/uri-guard-adapter.mjs

**Responsibility:** pi adapter for the URI guard — intercepts tool calls (from the `tool_call` event in index.ts) where the model is about to pass a `viking://` URI to a non-Viking tool (e.g. using `read` or `bash` on a viking:// path). Blocks the call and returns a corrective message telling the model which Viking tool to use instead, with a concrete example invocation.

**Main exports:**
- `guardVikingUriToolCall(event)` — inspects the tool event, normalizes the tool name via `normalizeToolName`, looks it up in `VIKING_URI_TOOL_HINTS`, scans the tool input for any `viking://` URI via `findVikingUri`, and returns `{ block: true, reason }` if found, or `null` (no interception) otherwise. The `reason` string is built via `buildGuardMessage` with the correct target tool and example.

**Guarded tool map (`VIKING_URI_TOOL_HINTS`):**
- `read` → use `viking_read(uri="...", level="overview")`
- `grep` → use `viking_search(query="...", scope="<uri>")` (pattern is extracted from input.pattern, quotes escaped)
- `find` / `ls` → use `viking_browse(action="list", uri="...")`
- `bash` → use `viking_read` or `viking_search`

Tool name and URI detection both come from `../shared/uri-guard.mjs`.

**Risks:**
- Hardcoded mapping is limited to the listed tools; if the model uses other tools (e.g. a custom `edit` or `write` tool, or a non-pi filesystem tool) with viking:// URIs they will not be blocked.
- The input scan looks at `event.input`, `event.args`, or `event.params` — if pi uses a different field name for tool arguments, the URI won't be found.
- Returns `{ block: true, reason }` — relies on pi honoring the `block` flag semantics; if pi changes or ignores that field, viking:// URIs could still reach filesystem tools.
- Grep hint escapes double quotes in pattern but not backslashes or other shell/JSON special characters; a pattern with complex characters could produce a malformed example.

---

## 22. src/uri-guard.test.mjs

**Responsibility:** Unit tests for the pi URI guard adapter. Verifies that builtin file tools and bash are blocked when given viking:// URIs, and that normal local paths plus native OpenViking tools are allowed through.

**Main exports:** None (test file). Uses `node:test`, `node:assert/strict`. Imports `guardVikingUriToolCall` from `../lib/uri-guard-adapter.mjs` (compiled output, not source).

**Test cases (3 tests):**
1. Blocks `read` with `viking://resources/project/file.md` as path — asserts `decision.block === true`, reason contains the standard "viking:// URIs are OpenViking virtual paths" message and mentions "Use viking_read instead".
2. Blocks `bash` with a `cat viking://...` command in the command string — asserts block is true, reason says "Use viking_read or viking_search instead".
3. Allows normal local paths (`/tmp/file.md` with read) and native viking tools (`viking_read` with a viking:// uri) — both return null.

**Risks:**
- Imports from `../lib/uri-guard-adapter.mjs` (compiled output) — stale lib/ would produce misleading passes.
- Only 3 tests; does not cover `grep`, `find`, `ls` tool hints, the alternate event field names (`tool_name`, `name`, `args`, `params`), nested objects containing viking:// URIs, mixed local+virtual paths in one command, or the quote-escaping in the grep example builder.
- Does not test that non-string arguments (e.g. `path` passed as an object or array) don't crash the guard.
