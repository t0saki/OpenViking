---
directory: viking://user/default/sessions/pi-01a08ee0-bf4b-7855-ad09-2af85dfeea53/history/archive_002/
generated_by:
  component: Session
  trigger: archive_summary
---

# Working Memory

## Session Title
Source inventory of 22 src/ files for OpenViking pi extension

## Current State
11 of 22 src/ files have been inventoried (files 1–11, alphabetical order), with entries appended to INVENTORY.md and corresponding checkboxes ticked in TASK.md. The session just completed a context window reset (w2 → w3) triggered by reaching ~46% usage after processing index-load.test.mjs. 11 files remain to be processed in order, starting with src/index.ts (~25KB, the main extension entry point). Work proceeds incrementally: read each file, append an INVENTORY.md entry, tick the TASK.md checkbox, then move to the next file.

## Task & Goals
Primary task: Execute the source inventory defined in TASK.md — work through all 22 files under src/ in alphabetical order. For each file: read its contents, append one entry to INVENTORY.md containing the file name, its responsibility, main exports, and any risky patterns, then tick the file off in TASK.md. Work incrementally (append after each file, do not batch), and never summarize files not yet read. The inventory supports future code navigation, risk assessment, and onboarding for the OpenViking pi extension codebase.

## Key Facts & Decisions
- Inventory scope: 22 files under src/ (~411 KB total), processed in strict alphabetical order as listed in TASK.md.
- Output artifacts: INVENTORY.md (created fresh at session start, appended per file) and TASK.md (checkboxes updated per file).
- Processing pattern: read tool → edit INVENTORY.md (append entry) → edit TASK.md (tick checkbox) → next file.
- INVENTORY entry schema per file: file name, responsibility description, main exports list, risk notes.
- Completed files (11/22, all ticked in TASK.md, all entries in INVENTORY.md):
  1. src/capture-adapter.mjs — extracts capture payloads from a conversation branch for archival; normalizes roles, handles tool results, applies faithful capture policy.
  2. src/capture-adapter.test.mjs — test suite for extractBranchCapturePayloads covering role normalization, watermark reset, faithful capture rules, tool result handling, truncation, deduplication.
  3. src/client-archives.test.mjs — test suite for OVClient archive-related methods (sessionRootUri, archiveUriToRoot, readArchiveOverview, readArchiveMessages, listSessionArchives, grepSessionArchives, getTask, commitSessionResponse).
  4. src/client.ts — full OpenViking HTTP client (OVClient class) covering sessions, archives, search, content, filesystem, resources, URI space resolution; failure-tolerant archive methods return null/[] instead of throwing.
  5. src/config.test.mjs — test suite for loadConfig covering defaults, env overrides, CLI config precedence, contextWindow merging/clamping, debug log paths, peer id resolution.
  6. src/config.ts — configuration loader (loadConfig, loadConfigFromModuleUrl) with defaults, config.json merge, env var overrides, value clamping, credential resolution, peer id derivation.
  7. src/context-window-adapter.test.mjs — test suite for the pi adapter of the context window manager, covering I/O delegation, error swallowing, persistence, pending queue counts, sleep/abort, reserve token reading.
  8. src/context-window-core.mjs — 2031-line pure harness-agnostic state machine for agent-managed context windows; virtual cut semantics, reset pipeline, header building, status lines, reminders, pi compaction fallback, persistence.
  9. src/context-window-core.test.mjs — 2167-line comprehensive test suite for ContextWindowCore and all exported pure helpers; covers cut semantics, header/handoff/status text, requestReset pipeline, refreshPendingOverview, reminders, status snapshot, pi compaction fallback, restore/shutdown, adversarial cases, abort/deadline/commit-transport, lazy session validation, archive ledger.
  10. src/context-window.ts — adapter binding pure ContextWindowCore to pi, OVClient, and SyncManager; exports createContextWindowManager and readPiReserveTokens.
  11. src/index-load.test.mjs — 969-line end-to-end smoke test loading index.ts through pi's jiti loader; verifies event/tool/command registration, reset flow, history tool, context cutting, offline restore, peer extension coexistence, stale usage guard, recall failure isolation, compaction guard, window id persistence.
- Faithful capture is fixed on in this fork (no captureMode toggle); the archive is the only way back to a closed window.
- Tool result capture is enabled by default; the `history` tool promises the archive is readable, so tool output must reach OpenViking.
- Context window reset is fail-closed: any refusal means nothing is cut, no history is lost.
- Archive methods in OVClient distinguish "empty history" (returns []) from "unreadable server" (returns null) — the two must never be conflated.
- Mixed import strategy across test files: some import from ../lib/*.mjs (compiled output), others from ../*.ts (TypeScript source).
- Multiple files import from ../shared/ (outside src/): capture-utils.mjs, credentials.mjs, workspace-peer.mjs, pending-queue.mjs.
- index.ts registers 9 tools total: 6 viking_* tools (search, read, browse, remember, forget, add_resource) + 3 context window tools (new_context, history, get_context_remaining), plus the "viking" command and 9 event handlers.
- index-load.test.mjs uses jiti loader (finds pi's bundled jiti at multiple candidate paths) and skips entirely if jiti is not found; spins up a real fake HTTP server with node:http createServer for end-to-end tests.
- Context window adapter imports ContextWindowCore from compiled ./lib/context-window-core.mjs (not source), and pi-settings from ./lib/pi-settings.mjs.
- readPiReserveTokens reads pi's compaction reserve from .pi/settings.json (project over global), used to clamp reminder thresholds below pi's auto-compaction line.
- The extension has a peer-extension coexistence mechanism: if another OpenViking extension already registered viking_search, this one stands down and notifies the user.

## Files & Context
- `/proj/TASK.md` — master task list with 22 checkboxes, 11 currently ticked; defines the inventory order and requirements.
- `/proj/INVENTORY.md` — growing inventory document, 11 entries written so far; appended to after each file read.
- `/proj/src/` — directory containing all 22 source files to be inventoried.
- `/proj/src/capture-adapter.mjs` — main export: extractBranchCapturePayloads; depends on ../shared/capture-utils.mjs and ./text-budget.mjs.
- `/proj/src/capture-adapter.test.mjs` — imports from ../lib/capture-adapter.mjs; uses node:test and node:assert/strict.
- `/proj/src/client-archives.test.mjs` — imports OVClient, archiveIdFromUri, archiveUriToRoot from ../client.ts; stubs global fetch.
- `/proj/src/client.ts` — OVClient class plus type exports and standalone helper functions; standalone exports: archiveUriToRoot, archiveIdFromUri.
- `/proj/src/config.test.mjs` — imports loadConfig, loadConfigFromModuleUrl from ../config.ts; uses temp directories and env var manipulation.
- `/proj/src/config.ts` — exports: EXTENSION_VERSION, OVContextWindowConfig interface, OVConfig interface, loadConfigFromModuleUrl, loadConfig; depends on ./shared/credentials.mjs and ./shared/workspace-peer.mjs.
- `/proj/src/context-window-adapter.test.mjs` — imports createContextWindowManager, readPiReserveTokens from ../context-window.ts; imports DEFAULT_RESERVE_TOKENS, pickReserveTokens, readReserveTokens, settingsPaths from ../lib/pi-settings.mjs; imports enqueue from ../shared/pending-queue.mjs.
- `/proj/src/context-window-core.mjs` — 2031 lines; key exports: WINDOW_ENTRY_TYPE, WINDOW_HEADER_OPEN, STATUS_CUSTOM_TYPE, REMINDER_CUSTOM_TYPE, HANDOFF_MARKER, STATUS_MARKER, REMINDER_MARKER, COMPACTION_SENTINEL, windowConfig, computeCutRange, applyWindowCut, buildHandoffMessage, buildWindowHeader, formatTokens, formatDuration, effectiveThresholds, buildStatusLine, reminderText, lastUserTimestamps, lastUserTextFromBranch, messagesFromBranch, siblingToolNamesFromBranch, messageTokens, ContextWindowCore class; depends on ./text-budget.mjs.
- `/proj/src/context-window-core.test.mjs` — 2167 lines; imports from ../lib/context-window-core.mjs and ../lib/text-budget.mjs; uses node:test and node:assert/strict.
- `/proj/src/context-window.ts` — exports: createContextWindowManager, readPiReserveTokens; imports ContextWindowCore from ./lib/context-window-core.mjs, DEFAULT_RESERVE_TOKENS/readReserveTokens from ./lib/pi-settings.mjs, listPending from ./shared/pending-queue.mjs.
- `/proj/src/index-load.test.mjs` — 969 lines; loads index.ts via jiti from pi's installation; uses node:test, node:http createServer, temp directories, env var manipulation.

## Errors & Corrections
- INVENTORY.md did not exist at session start (ENOENT error on first read); resolved by creating the file before writing the first entry.
- Initial read of TASK.md path was attempted at root level before confirming directory structure; resolved by running ls to confirm proj/ layout with src/ subdirectory and TASK.md at proj root.
- context-window-core.mjs was too large for a single read (truncated at 301-line offset, then 701, then 1101, then 1501); resolved by reading in chunks with offset parameter until end of file was reached and verified via wc -l (2031 lines total).
- The context-window-core.mjs entry (file 8) was lost during the w1→w2 context reset (TASK.md showed it unchecked, INVENTORY.md only had 7 entries); resolved by reconstructing and writing the entry at the start of w2 before proceeding to file 9.
- context-window-core.test.mjs was too large for a single read (2167 lines); resolved by reading in chunks at offsets 501, 1001, 1501, 2001 until complete.
- index-load.test.mjs was too large for a single read (969 lines); resolved by reading in chunks at offset 501.

## Open Issues
- 11 files remain to be inventoried (files 12–22): index.ts, pi-settings.mjs, recall-deferred.test.mjs, recall.ts, sync-barrier.test.mjs, sync.ts, text-budget.mjs, text-budget.test.mjs, tools.ts, uri-guard-adapter.mjs, uri-guard.test.mjs.
- index.ts at ~25KB and tools.ts at ~31KB are large files that will likely require multiple offset reads to fully capture.
- Several remaining files import from ../shared/ modules outside src/ — their full dependency picture will not be complete until those shared files are examined (though the current task only covers src/).
- Mixed .mjs/.ts import patterns across test suites may indicate a build step producing lib/ output — this has not been confirmed yet.
- No verification step has been run to confirm all 22 checkboxes are ticked and all 22 entries are present in INVENTORY.md — this should happen after the last file is processed.
- The fork ships no takeover module (takeover.ts, lib/takeover-core.mjs, shared/recall-ledger.mjs all absent) — verified by index-load.test.mjs; this is an intentional difference from upstream.

