# Demo material — long-context run, the agent resets under pressure

From a passing run of the new long scenario:

    E2E_WINDOW_LONG=1 E2E_LLM_REASONING=high bash scripts/e2e-window.sh

Model `doubao-seed-2-1-pro-260628` via an OpenAI-compatible relay, `reasoning_effort: high`,
pi told the window is 128k. 22 real source files (411 KB, ~105k tokens if read
in full) seeded into the project: more material than one window holds.
Gate result: all checks passed, no warnings.

The agent was never told to reset. It was given a task bigger than its window
and the three context tools, and it managed the window itself: three times it
checked its budget, wrote handoff notes, archived the window and carried on.

OpenViking session (kept on the server, delete when done):

    pi-01a08ee0-bf4b-7855-ad09-2af85dfeea53

## The shape of the run

| | |
| --- | --- |
| provider requests | 96 |
| windows | w1 → w2 → w3 → w4 (3 resets) |
| peak context | 240 KB ≈ 60.1k tokens ≈ **47% of 128k** (payload-t1-23) |
| after the reset | 21 KB ≈ 5k tokens |
| archives in OpenViking | 3, each with a generated Working Memory |
| work produced | INVENTORY.md covering 22/22 files, TASK.md fully ticked |

`pressure-timeline.txt` is the whole curve: context climbs, `new_context`
drops it, it climbs again. The saw-tooth is the demo.

## Files

| file | what to show |
| --- | --- |
| `pressure-timeline.txt` | the saw-tooth: 96 requests, 3 resets marked in place |
| `context-tool-calls.json` | the agent's own calls, including `get_context_remaining` before deciding |
| `window-header.txt` | what the model sees in the last fresh window |
| `payloads/payload-t1-23.json` | the fullest request, right before a reset |
| `payloads/payload-t1-24.json` | the first request after it: same turn, 2 messages |
| `work/INVENTORY.md` | the deliverable, written across four windows |
| `work/TASK.md` | the checklist the agent ticked off as it went |
| `archive/archive_00*.overview.md` | the Working Memory OpenViking wrote for each closed window |
| `archive/archive_00*.messages.jsonl` | the raw archived conversation, tool output included |
| `archive/grep-sample.json` | grep over the archives: what `history search_contents` runs |
| `ov-pi.log` | commit, archive wait (50 s, 90 s, 66 s) and window open for each reset |
| `session/*.jsonl` | pi session file: window state entries and `[context-status]` lines |
| `e2e-gate.log` | the full gate output |

## Suggested order

1. `pressure-timeline.txt` — the window fills to 47%, the agent resets, twice more.
2. `context-tool-calls.json` — read the first `reason` out loud: it names the
   percentage and how many files are left.
3. `payloads/payload-t1-23.json` vs `payload-t1-24.json` — 240 KB to 21 KB, same turn.
4. `work/INVENTORY.md` — the task still finished, 22/22.
5. `archive/archive_001.overview.md` — the summary is the server's, not the coding model's.
6. `ov-pi.log` — what it cost: 50-90 s per reset.

## Reproduce

    source .tmp/pi-ctxwin/env.sh
    OPENVIKING_URL="$OPENVIKING_URL" OPENVIKING_API_KEY="$OPENVIKING_API_KEY" \
    E2E_LLM_API_KEY="$PI_CTXWIN_LLM_KEY" E2E_LLM_BASE_URL="$PI_CTXWIN_LLM_BASE" \
    E2E_LLM_MODEL="$PI_CTXWIN_LLM_MODEL" E2E_LLM_API=openai-completions \
    E2E_LLM_REASONING=high E2E_WINDOW_LONG=1 E2E_KEEP_TMP=1 E2E_KEEP_OV_SESSION=1 \
    bash examples/pi-experimental-context-management/scripts/e2e-window.sh

Then `./.tmp/pi-ctxwin/pack-demo.sh <workspace> <outdir>` packages it like this.
Takes 25-40 minutes; the short scripted gate is in `../demo/`.
